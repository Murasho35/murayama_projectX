package collection;

import java.util.List;

public interface collectionSearchable {
	List<Addition> search(String keyword);
}


